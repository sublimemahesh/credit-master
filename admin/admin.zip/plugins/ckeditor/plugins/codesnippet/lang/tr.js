/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","tr",{button:"Kod parçacığı ekle",codeContents:"Kod",emptySnippetError:"Kod parçacığı boş bırakılamaz",language:"Dil",title:"Kod parçacığı",pathName:"kod parçacığı"});